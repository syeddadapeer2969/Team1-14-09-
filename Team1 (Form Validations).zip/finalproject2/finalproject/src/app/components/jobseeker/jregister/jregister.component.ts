import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormsModule, FormGroup, FormControl, Validators} from '@angular/forms';
import { ConfirmedValidator } from './../jregister/confirmed.validators';
@Component({
  selector: 'app-jregister',
  templateUrl: './jregister.component.html',
  styleUrls: ['./jregister.component.css']
})
export class JregisterComponent implements OnInit {

  user_name: any
  company_name:any
  email_id:any
  pass_word:any
  // password:any
  confirm_password:any
  Primary_number:any
  Secondary_number:any
  address:any
 
  constructor(private fb: FormBuilder) {}

    // this.form = fb.group({
    //   password: ['', [Validators.required]],
    //   confirm_password: ['', [Validators.required]]
    //   }, { 
    //   validator: ConfirmedValidator('password', 'confirm_password')
    //   })
    //   }
    //   get f(){
    //   return this.form.controls;
    //   }
   
      submit = () =>{
       let obj = {user_name: this.user_name, email_id: this.email_id, primary_number: this.Primary_number, Secondary_number: this.Secondary_number, 
        company_name: this.company_name, address: this.address, password:this.pass_word, confirm_password: this.confirm_password}
      // console.log(this.form.value);
      console.log(obj);
      }
      
  ngOnInit(): void {
  }
}

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
