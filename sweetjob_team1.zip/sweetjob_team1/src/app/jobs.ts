export class Jobs {
    role:any
    company_name:any
    location:any
    salary: any
    skills_required: any
  
    constructor(role: any, company_name: any, location: any, salary: any, skills_required: any ){
        this.role= role;
        this.company_name=company_name;
        this.location=location;
        this.skills_required = skills_required;
        this.salary = salary;

}
}
