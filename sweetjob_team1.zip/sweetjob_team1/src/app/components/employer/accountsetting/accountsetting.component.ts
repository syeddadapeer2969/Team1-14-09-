import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountsetting',
  templateUrl: './accountsetting.component.html',
  styleUrls: ['./accountsetting.component.css']
})
export class AccountsettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
