import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiledata',
  templateUrl: './profiledata.component.html',
  styleUrls: ['./profiledata.component.css']
})
export class ProfiledataComponent implements OnInit {

  qualification:any
experience:any
location:any
file:any
resume:any
id:any
  constructor() { }

  ngOnInit(): void {
  }
addProfile(){
  
}

 

}
