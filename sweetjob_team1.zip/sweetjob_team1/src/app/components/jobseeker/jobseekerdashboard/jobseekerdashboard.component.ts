import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobseekerdashboard',
  templateUrl: './jobseekerdashboard.component.html',
  styleUrls: ['./jobseekerdashboard.component.css']
})
export class JobseekerdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
