export class UserClass {
    _id: string='';
    username: string='';
    emailid: string='';
    password: string='';
  }