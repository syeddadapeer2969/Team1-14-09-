import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  public loginStatus = 0;// 0 = not logged in, 1 = logged in
  public jwtToken = '';// JWT - Json Web Token
  public _id = '';
  public username = '';
  public emailid = '';
  public password = '';
  public phone_number1=0;
  public phone_number2=0;
  public address='';

  // public birthdate = '';
  // public gender = '';
  // public photo = '';

  constructor() { }

  resetAll() {
    this.loginStatus = 0;
    this.jwtToken = '';
    this._id = '';
    this.username = '';
    this.emailid = '';
    this.password = '';
     this.phone_number1=0;
    this.phone_number2=0;
    this.address='';
  }
  setLoginStatus(status : number) {
    this.loginStatus = status;
  }
  getLoginStatus() {
    return this.loginStatus
  }
  //
  setJwtToken(token : string) {
    this.jwtToken = token;
  }
  getJwtToken() {
    return this.jwtToken;
  }
  // setphoto(x : string) {
  //   this.photo = x;
  // }
  // getphoto() {
  //   return this.photo;
  // }
  //
  set_id(x : string) {
    this._id = x;
  }
  get_id() {
    return this._id;
  }
  //
  setusername(x : string) {
    this.username = x;
  }
  getusername() {
    return this.username;
  }
  //
  setemailid(x : string) {
    this.emailid = x;
  }
  getemailid() {
    return this.emailid;
  }
  //
  setpassword(x : string) {
    this.password = x;
  }
  getpassword() {
    return this.password;
  }
}
